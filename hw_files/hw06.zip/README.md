To run, simply `cd` into the `code` directory and run `main.py`

Inspired the wonderful tutorial available here: https://www.youtube.com/watch?v=fo4e3njyGy0
and adapted for CS134 at Williams College.

An RPG made in Python that was inspired by Pokemon and the older Final Fantasy games. The code is CC0, you can use it for whatever purpose, including commercial projects. Attributions are appreciated but not required. 

The artwork was made by Scarloxy and you can find them here: https://scarloxy.itch.io/mpwsp01 

The sounds for the project are taken from a range of sources: 
Fire attack: https://opengameart.org/content/spell-4-fire
Slash attack: https://opengameart.org/content/knife-sharpening-slice-2
Crack sounds: https://opengameart.org/content/5-break-crunch-impacts
Overworld music: https://opengameart.org/content/nes-overworld-theme
Notice sound: https://opengameart.org/content/10-8bit-coin-sounds
Battle music: https://opengameart.org/content/boss-battle-1-8-bit-re-upload

