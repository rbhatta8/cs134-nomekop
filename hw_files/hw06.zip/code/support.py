from settings import *
from pygame.time import get_ticks
import pygame as pg
from pytmx.util_pygame import load_pygame
from pygame.math import Vector2 as vector
import os


CHAR_ROWS = 4
CHAR_COLS = 4
NOMEKOP_ROWS = 2
NOMEKOP_COLS = 4



def distance(s1, s2):
	return (((s1.rect.centerx - s2.rect.centerx)**2 + (s1.rect.centery - s2.rect.centery)**2)**0.5)


def player_is_blocked_by_object(player, collidable_sprites):
	r1_right = player.x + player.width
	r1_left = player.x
	r1_top = player.y
	r1_bot = player.y + player.height
	r1_centery = player.y + player.height/2
	r1_centerx = player.x + player.width/2
	
	i = 0
	while i < len(collidable_sprites):
		sprite = collidable_sprites[i]
		r2_right = sprite.x + sprite.width
		r2_left = sprite.x 
		r2_top = sprite.y
		r2_bot = sprite.y + sprite.height
		i += 1
		if player.direction == "right" and (r1_right - 50 > r2_left and r1_left < r2_left) and (r2_top <= r1_centery <= r2_bot):
			return True
		elif player.direction == "left" and (r1_left + 50 < r2_right and r1_right > r2_right) and (r2_top <= r1_centery<= r2_bot):
			return True
		elif player.direction == "down" and (r1_bot - 50 > r2_top and r1_top < r2_top) and (r2_left <= r1_centerx <= r2_right):
			return True
		elif player.direction == "up" and (r1_top + 50 < r2_bot and r1_bot > r2_bot) and (r2_left <= r1_centerx <= r2_right):
			return True
	
	return False
	
def return_y(s):
	if s.kind == "monster_patch":
		return s.rect.centery - 40
	else:
		return s.rect.centery


def import_maps(map_names):

    maps = {}

    for name in map_names:
        path = os.path.join("..", "data", "maps", name)
        maps[name] = load_pygame(path)

    return maps

def load_all_images(full_path, rows, cols):
	
	all_imgs = pg.image.load(full_path).convert_alpha()
	cell_width, cell_height = all_imgs.get_width() / cols, all_imgs.get_height() / rows

	frames = []
	for row in range(rows):
		for col in range(cols):
			img = all_imgs.subsurface((col * cell_width, row * cell_height, cell_width, cell_height))
			frames.append(img)
		
	return frames


def load_image(image_name):
    # loads a nomekop image icon given the name of the image, e.g., "Draem.png"
    path = os.path.join("..", "graphics", "icons", image_name)
    return pg.image.load(path).convert_alpha()

def flip_image(image):
    # flips an image horizontally
    return pg.transform.flip(image, True, False)

def load_char(image_name, flip=False):
    path = os.path.join("..", "graphics", "characters", image_name)
    images = load_all_images(path, 4, 4)
    image = images[4]
    if flip:
        image = flip_image(image)
    return image

def load_frames(nomekop, flip):
    # loads all frames relevant to a nomekop
    frames = []
    image_name = nomekop + ".png"
    path = os.path.join("..", "graphics", "nomekop", image_name)
    frames = load_all_images(path, 2, 4)[0:4]
    if nomekop in LEGENDARY:
        path = os.path.join("..", "graphics", "attacks", "ice.png")
        frames = frames + load_all_images(path, 1, 4)
    elif nomekop in FIRE:
        path = os.path.join("..", "graphics", "attacks", "explosion.png")
        frames = frames + load_all_images(path, 1, 4)

    elif nomekop in PLANT:
        path = os.path.join("..", "graphics", "attacks", "plant.png")
        frames = frames + load_all_images(path, 1, 4)

    elif nomekop in WATER:
        path = os.path.join("..", "graphics", "attacks", "water.png")
        frames = frames + load_all_images(path, 1, 4)

    if flip:
        frames = [flip_image(image) for image in frames]
    return frames