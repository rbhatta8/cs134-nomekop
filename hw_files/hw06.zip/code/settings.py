PLAYER_FILE = "c10.png"
CEO_FILE = "c9.png"
WINDOW_WIDTH, WINDOW_HEIGHT = 1280, 720
TILE_SIZE = 64 
ANIMATION_SPEED = 6
WALKING_SPEED = 250
BATTLE_OUTLINE_WIDTH = 4

COLORS = {
	'white': '#f4fefa', 
	'snow-white': '#ffffff',
	'dark': '#2b292c',
	'light': '#c8c8c8',
	'gray': '#3a373b',
	'gold': '#ffd700',
	'light-gray': '#4b484d',
	'fire':'#f8a060',
	'water':'#50b0d8',
	'plant': '#64a990', 
	'black': '#000000', 
	'red': '#f03131',
	'blue': '#66d7ee'
}

WORLD_LAYERS = {
	'water': 0,
	'bg': 1,
	'shadow': 2,
	'main': 3,
	'top': 4
}

FIRE = ["Charmadillo", "Cindrill", "Jacana", "Sparchu"]
WATER = ["Draem", "Finiette", "Finsta", "Gulfin"]
PLANT = ["Atrox", "Cleaf", "Ivieron", "Larvea", "Pluma", "Plumette"]
LEGENDARY = ["Friolera"]