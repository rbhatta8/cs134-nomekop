from settings import *
import pygame as pg
from pytmx.util_pygame import load_pygame
from support import load_all_images, player_is_blocked_by_object
import sys
import os
from time import time
from random import randint
from itertools import combinations

class Sproot:
    def __init__(self, name, x, y, width, height, images):
        self.name = name
        # attributes defining the rectangle
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        # attributes controlling how the sproot gets drawn on screen
        self.all_images = images # list of all images for this sprite
        self.current_image = self.all_images[0] # set current image
        self.direction = "left"  

def load_terrain(map):
    
    # get terrain tiles
    terrain = map.get_layer_by_name("Terrain")
    terrain_sproots = []
    for x, y, surface in terrain.tiles():
        s = Sproot("terrain", x * TILE_SIZE,  y * TILE_SIZE, TILE_SIZE, TILE_SIZE, images=[surface])
        terrain_sproots += [s]

    return terrain_sproots

def load_objects(map):
    
    # get terrain tiles
    objects = map.get_layer_by_name("Objects")
    object_sproots = []
    for object in objects:
        s = Sproot("obj", object.x, object.y, object.width, object.height, [object.image])
        object_sproots += [s]
    return object_sproots


def time_functions(player_sproot, sproots, num_trials, max_y):

    # write code to time the sorting of the list (sproots + [player_sproot]) several times (as indicated by num_trials)
    # for each trial, the player_sproot should have its y coordinate updated to
    # a random y coordinate between 0 and max_y coordinate
    # remember you can use the time() function to get the current time
    print("SORT TIME", 0)

    # write code to time insertion of player_sproot in the correct position in sproots several times (as indicated by num_trials)
    # for each trial, the player_sproot should have its y coordinate updated to
    # a random y coordinate between 0 and max_y coordinate
    print("INSERT TIME", 0)

def insert_player(player_sproot, sproots):
    
    # change this code to insert the player at the correct position in O(n) time
    return sproots + [player_sproot]

def sort_sproots(sproots):

    # code for sorting sproots in O(n^2) time
    return sproots

def move_player(player_sproot, object_sproots, key_pressed_map, time, walking_speed):
    # code to move player
    return player_sproot

def update_sproot_image(sproot, frame):
    # code to update image of a sproot based on the given frame and direction the sproot is facing
    return sproot

def draw(image, screen, pos_x, pos_y):
    screen.blit(image, (pos_x, pos_y))

def run_timings():
    # SETUP CODE
    pg.init()
    screen = pg.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
    pg.display.set_caption("Nomékop")
    path = os.path.join("..", "data", "maps", "world.tmx")
    world_map = load_pygame(path)
    object_sproots = load_objects(world_map)

    path = os.path.join("..", "graphics", "characters", PLAYER_FILE)
    player_images = load_all_images(path, 4, 4)
    player_sproot = Sproot("Player", 960, 832, 128, 128, player_images)
    
    path = os.path.join("..", "graphics", "nomekop", "Friolera.png")
    friolera_images = load_all_images(path, 2, 4)
    friolera_sproot = Sproot("Friolera", 1160, 832, 150, 150, friolera_images)
    object_sproots += [friolera_sproot]
    time_functions(player_sproot, object_sproots, 10000, 10000)

def is_perfect_number(num):
    return False

def is_practical_number(num):
    return False

def run_game():

    # initial setup code
    pg.init()
    screen = pg.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
    pg.display.set_caption("Nomékop")
    clock = pg.time.Clock()
    world_map = load_pygame(os.path.join("..", "data", "maps", "world.tmx"))

    # loading player and friolera images
    player_image_path = os.path.join("..", "graphics", "characters", PLAYER_FILE)
    ceo_image_path = os.path.join("..", "graphics", "characters", CEO_FILE)
    friolera_image_path = os.path.join("..", "graphics", "nomekop", "Friolera.png")
    player_images = load_all_images(player_image_path, 4, 4)
    ceo_images = load_all_images(ceo_image_path, 4, 4)
    friolera_images = load_all_images(friolera_image_path, 2, 4)
    
    # 0a create player and friolera sproots here
    player_sproot = None
    friolera_sproot = None
    terrain_sproots = load_terrain(world_map)
    object_sproots = load_objects(world_map)
    object_sproots += [friolera_sproot]

    # if is_practical_number(666):
    #     audio_path = os.path.join("..", "data", "audio", "mystery.mp3")
    #     music = pg.mixer.Sound(audio_path)
    #     music.play()
    #     ceo_sproot = Sproot("CEO", 1111, 832, 128, 128, ceo_images)
    #     print("CEO: Muahahaha 666 is my calling card! What a perfectly practical number! So.. you've been trying to steal my Friolera eh? I need to keep a better eye on you...")
    #     object_sproots += [ceo_sproot]

    object_sproots = sort_sproots(object_sproots)
    frame = 0

    while True:
        
        time = clock.tick() / 1000
        # event loop
        for event in pg.event.get():
            if event.type == pg.QUIT:
                 pg.quit()
                 sys.exit()

        # update the frame based on time and animation speed
        frame += time * ANIMATION_SPEED

        # player movement logic and animation logic
        key_pressed_map = pg.key.get_pressed()
        # player_sproot = move_player(player_sproot, object_sproots, key_pressed_map, time, WALKING_SPEED)
        # player_sproot = update_sproot_image(player_sproot, frame)
        # friolera_sproot = update_sproot_image(friolera_sproot, frame)

        # drawing logic
        # x_offset = -(player_sproot.x + player_sproot.width/2 - WINDOW_WIDTH/2)
        # y_offset = -(player_sproot.y + player_sproot.height/2 - WINDOW_HEIGHT/2)  

        # always reset the screen with a blank slate first
        screen.fill("black")


        pg.display.update()


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "times":
        print("Running timing tests")
        run_timings()

    elif len(sys.argv) > 1 and sys.argv[1] == "nums":
        print()
        print("Running tests for perfect numbers --- printing all perfect numbers till 100")
        for i in range(1, 101):
            if is_perfect_number(i):
                print(i, "is a perfect number")

        print()
        print("Running tests for perfect numbers --- printing all practical numbers till 100")
        for i in range(1, 101):
            if is_practical_number(i):
                print(i, "is a practical number")
    else:
        run_game()