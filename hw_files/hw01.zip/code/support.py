from settings import *
import pygame as pg
from pytmx.util_pygame import load_pygame
import os

CHAR_ROWS = 4
CHAR_COLS = 4
NOMEKOP_ROWS = 2
NOMEKOP_COLS = 4

class Sproot:
    def __init__(self, image=None, rect=None, direction=None, all_images=None, kind=None):
        self.image = image
        self.rect = rect
        self.direction = direction
        self.all_images = all_images
        self.kind = kind

def return_y(s):
	if s.kind == "monster_patch":
		return s.rect.centery - 40
	else:
		return s.rect.centery


def import_maps(map_names):

    maps = {}

    for name in map_names:
        path = os.path.join("..", "data", "maps", name)
        maps[name] = load_pygame(path)

    return maps

def load_all_images(full_path, rows, cols):
	
	all_imgs = pg.image.load(full_path).convert_alpha()
	cell_width, cell_height = all_imgs.get_width() / cols, all_imgs.get_height() / rows

	frames = []
	for row in range(rows):
		for col in range(cols):
			img = all_imgs.subsurface((col * cell_width, row * cell_height, cell_width, cell_height))
			frames.append(img)
		
	return frames
