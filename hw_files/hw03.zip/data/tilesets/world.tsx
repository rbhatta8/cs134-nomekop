<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="world" tilewidth="64" tileheight="64" tilecount="210" columns="10">
 <image source="../../graphics/tilesets/world.png" width="640" height="1344"/>
</tileset>
