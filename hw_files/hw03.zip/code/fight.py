from support import draw


# type your answer to the question in 2 here

def fight_is_over(player_nomekop, opp_nomekop, attack_time):
    # implement your code here
    return False

def draw_nomekop_icons(screen, nomekop_icons, starting_x, starting_y):
    # write your logic here (delete the pass statement below)
    pass

def determine_nomekop_element(nomekop):
    fire = ["Charmadillo", "Cindrill", "Jacana", "Sparchu"]
    water = ["Draem", "Finiette", "Finsta", "Gulfin"]
    plant = ["Atrox", "Cleaf", "Ivieron", "Larvea", "Pluma", "Plumette"]
    legendary = ["Friolera"]
    # implement your logic here, must return a string---one of fire, water, plant, or legendary
    # should be all lower case
    return ""

def determine_winner(player_nomekop, opp_nomekop):
    # implement your logic here
    return "player"

def compute_updated_nomekop_list(nomekop, nomekop_list):

    updated_list = []
    # implement your logic here
    return updated_list

if __name__ == "__main__":
    # add two more tests here for 0b
    print(fight_is_over(["Larvea", "Plumette"], ["Atrox"], -1))
    print(determine_winner("Plumette", "Friolera"))
    print(determine_winner("Plumette", "Ivieron"))
    print(determine_winner("Plumette", "Finiette"))
