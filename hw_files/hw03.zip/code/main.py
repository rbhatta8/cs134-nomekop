from settings import *
import pygame as pg
from support import draw, load_char, load_icons, load_frames
import sys
import os
from fight import *
from random import randint


def run_game():

    # setup the screen
    pg.init()
    pg.display.set_caption("Nomékop")
    clock = pg.time.Clock()    
    bg_image = pg.image.load(os.path.join("..", "graphics", "backgrounds", "beach.png"))
    screen = pg.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
    player_image = load_char(PLAYER_FILE, True)
    opp_image = load_char(OPP_FILE, False)
    frame = 0

    # setup variables to track the game state
    active_player_nomekop = ""
    active_opp_nomekop = ""
    active_player_frames = None
    active_opp_frames = None
    attack_time = 0
    nomekop_chosen = False
    winner = ""

    # setup the player and opponent's nomekop
    player_nomekop = ["Plumette", "Sparchu", "Larvea"]
    opp_nomekop = ["Ivieron", "Friolera", "Finiette"]
    
    while True:
        
        # variable that records the amount of time
        # that has passed since we started the game
        time = clock.tick() / 1000

        if fight_is_over(player_nomekop, opp_nomekop, attack_time):
            # question 0b add logic to check who won and print a suitable message before quitting
            pg.quit()
            sys.exit()
        
        # event loop
        user_actions = pg.event.get()
        i = 0
        while i < len(user_actions):
            
            action = user_actions[i]
            i = i + 1

            if action.type == pg.QUIT:
                pg.quit()
                sys.exit()

            # complete code here to fully implement the pseudocode in 2
            elif action.type == pg.KEYDOWN and action.key == pg.K_SPACE:
                active_player_nomekop = player_nomekop[0]
                active_opp_nomekop = opp_nomekop[0]
                active_player_frames = load_frames(active_player_nomekop, True)
                active_opp_frames = load_frames(active_opp_nomekop, False)

            # complete code here to fully implement the pseudocode in 2
            elif action.type == pg.KEYDOWN and action.key == pg.K_f:
                winner = ""

            # complete code here to fully implement the pseudocode in 2
            elif action.type == pg.KEYDOWN and action.key == pg.K_d:   
                nomekop_chosen = False
                winner = ""

        # code to draw
        opp_icons = load_icons(opp_nomekop, False)
        player_icons = load_icons(player_nomekop, True)
        draw(screen, bg_image, 0, 0)
        draw(screen, player_image, 100, 400)
        draw(screen, opp_image, 1100, 400)

        frame = frame + ANIMATION_SPEED * time
        frame_index = int(frame % 4)
        if nomekop_chosen:
            draw(screen, active_player_frames[frame_index], 400, 400)
            draw(screen, active_opp_frames[frame_index], 730, 400)

        if attack_time > 0:
            if winner == "opp":
                draw(screen, active_opp_frames[1*4 + frame_index], 400, 400)
            elif winner == "player":
                draw(screen, active_player_frames[1*4 + frame_index], 730, 400)
            attack_time = attack_time - time
        
        pg.display.update()

if __name__ == "__main__":
    run_game()