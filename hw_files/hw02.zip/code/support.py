from settings import *
import pygame as pg
from pytmx.util_pygame import load_pygame
import os

CHAR_ROWS = 4
CHAR_COLS = 4
NOMEKOP_ROWS = 2
NOMEKOP_COLS = 4

class Sproot:
	def __init__(self, image=None, rect=None, direction=None, all_images=None, kind=None, active=False):
		self.image = image
		self.rect = rect
		self.direction = direction
		self.all_images = all_images
		self.kind = kind
		self.active = active

def player_is_blocked_by_object(player, collidable_sprites):
	r1 = player.rect
	
	i = 0
	while i < len(collidable_sprites):
		r2 = collidable_sprites[i].rect
		i += 1
		if player.direction == "right" and (r1.right - 50 > r2.left and r1.left < r2.left) and (r2.top <= r1.centery <= r2.bottom):
			return True
		elif player.direction == "left" and (r1.left + 50 < r2.right and r1.right > r2.right) and (r2.top <= r1.centery <= r2.bottom):
			return True
		elif player.direction == "down" and (r1.bottom - 50 > r2.top and r1.top < r2.top) and (r2.left <= r1.centerx <= r2.right):
			return True
		elif player.direction == "up" and (r1.top + 50 < r2.bottom and r1.bottom > r2.bottom) and (r2.left <= r1.centerx <= r2.right):
			return True
	
	return False
	
def return_y(s):
	if s.kind == "monster_patch":
		return s.rect.centery - 40
	else:
		return s.rect.centery


def import_maps(map_names):

    maps = {}

    for name in map_names:
        path = os.path.join("..", "data", "maps", name)
        maps[name] = load_pygame(path)

    return maps

def load_all_images(full_path, rows, cols):
	
	all_imgs = pg.image.load(full_path).convert_alpha()
	cell_width, cell_height = all_imgs.get_width() / cols, all_imgs.get_height() / rows

	frames = []
	for row in range(rows):
		for col in range(cols):
			img = all_imgs.subsurface((col * cell_width, row * cell_height, cell_width, cell_height))
			frames.append(img)
		
	return frames
