# type your answers to 0b here as comments

def player_is_near_aggressive_nomekop(nomekop_x, nomekop_y, player_x, player_y, kind):
    return False

def player_is_behind_snake(nomekop_x, nomekop_y, player_x, player_y, player_direction):
    return False

def translate_snake_dna(dna):
    protein = ""
    return protein


if __name__ == "__main__":
    seq = "GGGATGGCCAAT"
    print("The DNA sequence", seq, "translates to")
    print(translate_snake_dna(seq))