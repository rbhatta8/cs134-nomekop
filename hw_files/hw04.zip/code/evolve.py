from random import randint

# type your answers to 0b here


AMINO_ACIDS = ['A', 'C', 'E', 'F', 'G', 'H', 'I', 'L', 'N', 'O', 'P', 'R', 'S', 'W']

def produce_first_generation(num_individuals, sequence_length):
    
    generation = []
    for i in range(num_individuals):
        sequence = ""
        for j in range(sequence_length):
            sequence = sequence + AMINO_ACIDS[randint(0, len(AMINO_ACIDS)-1)]
        generation = generation + [sequence]

    return generation

def compute_fitness_score(sequence, target):

    score = 0


    return score


def crossover(sequence1, sequence2):
    
    new_sequence = ""
    
    return new_sequence


def mutate(sequence):
    
    mutated_sequence = ""

    
    return mutated_sequence

def find_best_sequence(sequences, target):

    best_score = 0
    best_sequence = ""

    

    return best_sequence


def create_weighted_pool(sequences, target):

    pool = []

    
    return pool


def evolution(num_individuals, target):

    sequences = produce_first_generation(num_individuals, len(target))
    best_sequence = ""
    gen_number = 1

    

    return best_sequence


if __name__ == "__main__":
    test_generation = produce_first_generation(10, 5)
    print(compute_fitness_score("LARVA", "CLEAF"))
    print(compute_fitness_score("CAEVA", "CLEAF"))
    print(crossover("LARVA", "CLEAF"))
    print(mutate("."*500))
    print(find_best_sequence(["DMFBF", "DMFAF", "LARVA"], "CLEAF"))
    print(create_weighted_pool(["DMFBF", "DMFAF", "LARVA"], "CLEAF"))
    evolution(1000, "CLEAFHASWINGS")