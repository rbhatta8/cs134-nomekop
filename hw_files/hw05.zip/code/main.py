from settings import *
import pygame as pg
from pygame.math import Vector2 as vector
from support import load_all_images, load_frames, import_maps, Sproot, return_y, player_is_blocked_by_object
import sys
import os
from icebreaker import *


def setup_area(map, player_start_pos):
    
    # initialize list of sprites
    bg_sprites, main_sprites, fg_sprites, animated_sprites, collidable_sprites, nomekop_sprites = [], [], [], [], [], []

    # get terrain tiles
    terrain = map.get_layer_by_name("Terrain")
    for x, y, surface in terrain.tiles():
        position = (x * TILE_SIZE, y * TILE_SIZE)
        s = Sproot(surface, surface.get_frect(topleft = position))
        bg_sprites.append(s)

    # get water tiles
    water = map.get_layer_by_name("Water")
    path = os.path.join("..", "graphics", "tilesets", "water.png")
    water_images = load_all_images(path, 1, 4)
    for w in water:
        position = (w.x, w.y)
        s = Sproot()
        s.image = water_images[0]
        s.rect = s.image.get_frect(topleft = position)
        s.all_images = water_images
        bg_sprites.append(s)
        animated_sprites.append(s)

    # get coast tiles
    terrain_types = ["grass", "grass_i", "sand_i", "sand", "rock", "rock_i", "ice", "ice_i"]
    sides = ["topleft", "top", "topright", "left", "right", "bottomleft", "bottom", "bottomright"]
    coast_images = {}
    for t in terrain_types:
        for s in sides:
            ts = f"{t}_{s}"
            path = os.path.join("..", "graphics", "tilesets", f"{ts}.png")
            coast_images[ts] =  load_all_images(path, 1, 4)
    coast = map.get_layer_by_name("Coast")
    for c in coast:
        position = (c.x, c.y)
        t = c.terrain
        s = c.side
        ts = f"{t}_{s}"
        s = Sproot()
        s.image = coast_images[ts][0]
        s.rect = s.image.get_frect(topleft = position)
        s.all_images = coast_images[ts]
        bg_sprites.append(s)
        animated_sprites.append(s)

    # get main objects
    objects = map.get_layer_by_name("Objects")
    for object in objects:
        position = (object.x, object.y)
        s = Sproot(object.image, object.image.get_frect(topleft = position))
        if object.name == "top":
            fg_sprites.append(s)
        else:
            main_sprites.append(s)
            collidable_sprites.append(s)

    # get monster patches
    objects = map.get_layer_by_name("Monsters")
    for object in objects:
        position = (object.x, object.y)
        s = Sproot(object.image, object.image.get_frect(topleft = position))
        s.kind = "monster_patch"
        main_sprites.append(s)

    # get player + other characters
    entities = map.get_layer_by_name("Entities")
    player_sprite = None
    for entity in entities:
        is_valid_entity = False
        if entity.name == "Player" and entity.properties["pos"] == player_start_pos:
            s = Sproot()
            player_sprite = s
            path = os.path.join("..", "graphics", "characters", PLAYER_FILE)
            images = load_all_images(path, 4, 4)
            is_valid_entity = True
        
        elif entity.name == "Professor":
            s = Sproot()
            prof_sprite = s
            path = os.path.join("..", "graphics", "characters", PROFESSOR_FILE)
            images = load_all_images(path, 4, 4)
            is_valid_entity = True
            s.active = True
            collidable_sprites.append(s)

        elif entity.name == "Character":
            s = Sproot()
            name = entity.properties["graphic"]
            path = os.path.join("..", "graphics", "nomekop", f"{name}.png")
            images = load_frames(name, flip=False)
            is_valid_entity = True
            s.kind = name
            s.active = True
            nomekop_sprites.append(s)
            collidable_sprites.append(s)
        
        if is_valid_entity:
            position = (entity.x, entity.y)
            s.image = images[0]
            s.rect = s.image.get_frect(topleft = position)
            s.all_images = images
            s.direction = 0
            main_sprites.append(s)


    return bg_sprites, main_sprites, fg_sprites, animated_sprites, nomekop_sprites, collidable_sprites, player_sprite, prof_sprite

def distance(s1, s2):
    return (vector(s1.rect.center)-vector(s2.rect.center)).length()

def run_game():

    pg.init()
    screen = pg.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
    pg.display.set_caption("Nomékop")
    clock = pg.time.Clock()
    map_names = ["world.tmx"]
    super_secret = ["CLEAFHASWINGS", "CLEAFHASHORNS", "CLEAFHASPINCERS"]
    messages_success = ["Prof. Herb: Yes, that's a good start!", "Prof. Herb: Good, good, keep going!", "Prof. Herb: Yes, of course, that's it, Cleaf has wings, horns, and pincers!"]
    messages_fail = ["Prof. Herb: Hmm something's not quite right here...", "Prof. Herb: Hmm something's not quite right here...", "Prof. Herb: Hmm something's not quite right here..."]
    num_success = 0
    maps = import_maps(map_names)
    
    bg_sprites, main_sprites, fg_sprites, animated_sprites, nomekop_sprites, collidable_sprites, player_sprite, prof_sprite = setup_area(maps["world.tmx"], "water")
    friolera = [nomekop for nomekop in nomekop_sprites if nomekop.kind == "Friolera"][0]
    sparchu = [nomekop for nomekop in nomekop_sprites if nomekop.kind == "Sparchu"][0]
    main_sprites = [s for s in main_sprites if s.kind != "Friolera"]
    collidable_sprites = [s for s in collidable_sprites if s.kind != "Friolera"]
    frame = 0
    larvea = [nomekop for nomekop in nomekop_sprites if nomekop.kind == "Larvea"]
    font = pg.font.SysFont('Arial', 32)
    tag_font = pg.font.SysFont('Arial', 32, bold=True)
    text_surface = font.render('Some Text', False, COLORS['black'])
    tag = tag_font.render("X", False, COLORS['red'])
    tag_pos = [3000, 3000]
    coords = [[3000, 3000]]*10
    power = 21
    power_text = font.render('power = ' + str(power), False, COLORS['fire'])
    timer = 0
    win_flag = False
    audio_flag = False
    temp = None

    while True:
        
        time = clock.tick() / 1000
        # event loop
        for event in pg.event.get():
            if event.type == pg.QUIT:
                 pg.quit()
                 sys.exit()

            if event.type == pg.KEYDOWN and event.key == pg.K_r:
                power = sparchu_random_power_up(power)
                power_text = font.render('power = ' + str(power), False, COLORS['fire'])

            if event.type == pg.KEYDOWN and event.key == pg.K_e:
                sparchu_energy_boost(power, [randint(1, 15) for _ in range(10)])
                if power < 42:
                    power += 1
                else:
                    power = 21
                power_text = font.render('power = ' + str(power), False, COLORS['fire'])

            if event.type == pg.KEYDOWN and event.key == pg.K_f:
                text = determine_readiness(player_sprite.rect.center, friolera.rect.center, power)
                if text == "Ready for blast off!":
                    win_flag = True
                    timer = 2
                    audio_path = os.path.join("..", "data", "audio", "void.mp3")
                    if not audio_flag:
                        victory = pg.mixer.Sound(audio_path)
                        victory.play()
                        audio_flag = True
                    player_sprite.rect.centerx -= 150
                    player_sprite.direction = "right"
                else:
                    print(text)
                

        keys = pg.key.get_pressed()
        input_vector = vector()
        frame += ANIMATION_SPEED * time
        frame_index = int(frame % 4)

        # player movement
        if keys[pg.K_DOWN]:
            input_vector.y += 1
            player_sprite.direction = "down"
            player_sprite.image = player_sprite.all_images[0*4 + frame_index]

        elif keys[pg.K_LEFT]:
            input_vector.x -= 1 
            player_sprite.direction = "left"
            player_sprite.image = player_sprite.all_images[1*4 + frame_index]

        elif keys[pg.K_RIGHT]:
            input_vector.x += 1
            player_sprite.direction = "right"
            player_sprite.image = player_sprite.all_images[2*4 + frame_index]

        elif keys[pg.K_UP]:
            input_vector.y -= 1
            player_sprite.direction = "up"
            player_sprite.image = player_sprite.all_images[3*4 + frame_index]

        if not player_is_blocked_by_object(player_sprite, collidable_sprites):
            player_sprite.rect.center += time * input_vector * WALKING_SPEED

        # drawing logic
        screen.fill("black")
        offset = vector()
        offset.x = -(player_sprite.rect.center[0] - WINDOW_WIDTH/2)
        offset.y = -(player_sprite.rect.center[1] - WINDOW_HEIGHT/2)

        if win_flag and timer <= 0:
            text_surface = font.render('Face-to-face with Friolera... but now what..', False, COLORS['white'])
            temp = "Friolera"
            main_sprites = [player_sprite, friolera]  
            bg_sprites = []
            fg_sprites = []
            win_flag = False          


        for i in range(len(animated_sprites)):
            animated_sprites[i].image = animated_sprites[i].all_images[0*4 + frame_index]

        for i in range(len(nomekop_sprites)):
            nomekop_sprites[i].image = nomekop_sprites[i].all_images[0*4 + frame_index]

        for sprite in bg_sprites + sorted(main_sprites, key=return_y) + fg_sprites:
            screen.blit(sprite.image, sprite.rect.topleft + offset)

        if keys[pg.K_t]:
            temp = measure_temperature(int(player_sprite.rect.centerx), int(player_sprite.rect.centery), friolera.rect.centerx, friolera.rect.centery)
            coords[int(frame % 10)] = [player_sprite.rect.centerx, player_sprite.rect.centery]

            tag_pos = place_geotag(tag_pos, [friolera.rect.centerx, friolera.rect.centery], coords)
            if abs(temp) < 10:
                temp = str(temp) + "  "
            text_surface = font.render(str(temp)+"°C", False, COLORS['black'])
            screen.blit(text_surface, player_sprite.rect.topleft + offset + vector((30, -16)))
            screen.blit(tag, tag_pos + offset)

        if temp == "Friolera":
            screen.blit(text_surface, player_sprite.rect.topleft + offset + vector((-200, -16)))

        else:
            screen.blit(power_text, sparchu.rect.topleft + offset + vector((30, 0)))

        if timer > 0:
            timer -= time
            screen.blit(sparchu.all_images[1*4 + frame_index], friolera.rect.topleft + offset)

        pg.display.update()

if __name__ == "__main__":
    run_game()