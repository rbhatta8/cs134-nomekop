from random import randint

def distance(x1, y1, x2, y2):
    # x1, x2, x2, y2 are all floats
    return ((x1-x2)**2 + (y1-y2)**2)**0.5

def measure_temperature(player_x, player_y, friolera_x, friolera_y):
    # player_x, player_y, friolera_x, friolera_y are all floats
    
    # part 0b, what do the following function calls return
    # print(measure_temperature(3, 4, 0, 0))
    # print(measure_temperature(300, 400, 0, 0))
    d = distance(player_x, player_y, friolera_x, friolera_y)
    temp = -int(5000//(d+1))
    return max(-42, temp)

def sparchu_random_power_up(power):
    # power is an integer
    # part 0c, what _can_ the following function calls print and what does it return
    # HINT: make sure to take out any options that are impossible for each
    # print(sparchu_random_power_up(21))
    # print(sparchu_random_power_up(29))
    # print(sparchu_random_power_up(34))

    power += randint(1, 13)
    
    if power > 21 and power < 35:
        print("Sparchu is cooking!")
    elif power < 42:
        print("Sparchu is close to full charge!")
    elif power == 42:
        print("Sparchu is fully charged!")
    else:
        power = 21
        print("Sparchu overcooked...")

    return power

def ordered(temperatures):
    # temperatures is a list of integers
    
    # part 0d, what is the computational complexity of this function in Big-O notation
    
    # part 0d, in one sentence, what is the purpose of this function?
    i = 0
    while i < len(temperatures) - 1:
        if temperatures[i] > temperatures[i+1]:
            return False
        i += 1
    return True
 
def sparchu_energy_boost(power, temperatures):
    # temperatures is a list of integers
    
    # part 1a, what is the computational complexity of this function in Big-O notation
    
    # part 1a, what does the following function call print and what does it return
    # sparchu_energy_boost(41, [50, 10, 20, 40, 80])
    
    N = len(temperatures)
    for i in range(0, N):
        j = 0
        while j < (N - i - 1):
            if temperatures[j] > temperatures[j + 1]:
                temp = temperatures[j]
                temperatures[j] = temperatures[j+1]
                temperatures[j+1] = temp
            j += 1

    if ordered(temperatures):
        power += 1
    
    if power == 42:
        print("Sparchu is fully charged!")
    
    elif power < 42:
        print("Sparchu received a boost!")
    
    else:
        print("Sparchu overcooked...")

    return temperatures

def place_geotag(curr_tag, friolera_coords, coordinates):
    # curr_tag is a list of length two consisting of x, y coordinates
    # friolera_coords is a list of length two containing x, y coords of the player
    # coordinates is a list of lists of x, y coordinates that the player has recently visited
        # e.g., [ [100, 200], [400, 500], [0, 0] ]
    # the 0th index of the above list is then the list [100, 200]

    # part 1b, what is the computational complexity of this function in Big-O notation

    # part 1b, what do the following function calls return
    # place_geotag([3, 4], [0, 0], [ [100, 100], [2025, 2026], [400, 400] ])
    # place_geotag([300, 400], [0, 0], [ [3, 4], [30, 40], [8000, 8000] ])
    
    coords = curr_tag
    low = measure_temperature(curr_tag[0], curr_tag[1], friolera_coords[0], friolera_coords[1])

    for i in range(len(coordinates)):
        temp = measure_temperature(coordinates[i][0], coordinates[i][1], friolera_coords[0], friolera_coords[1])
        if temp <= low:
            low = temp
            coords = coordinates[i]

    return coords

def determine_readiness(player_coords, friolera_coords, power):
    # player_coords is a list of length two containing x, y coords of the player
    # friolera_coords is a list of length two containing x, y coords of where friolera might be
    # power is an integer
    # should return "Ready for blast off!" when the player is at coordinates that give -42C temperature and sparchu power is 42
    # should return "Hmm, one of us doesn't seem ready" when only one of the above conditions is met
    # should return "Neither of us are ready" if neither condition is met

    # part 1c, implement the determine_readiness function as described above
    
    return "Neither of us are ready"
    

# FINAL PART, part 2:
# run main.py and try to find Friolera
# hold down T on your keyboard to monitor the temperatures
# press R to use the sparchu_random_power_up function
# press E to use the sparchu_energy_boost function
# press F to check if both you and sparchu are ready and in position to discover Friolera!

# part 3 bonus, rewrite sparchu energy boost using insertion sort instead of bubble sort


if __name__ == "__main__":
    print("Determine ready tests")
    print(determine_readiness([3, 4], [0, 0], 42))
    print(determine_readiness([3, 4], [0, 0], -42))
    print(determine_readiness([4000, 4000], [0, 0], 21))