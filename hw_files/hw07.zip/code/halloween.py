from PIL.Image import open as open_image
from PIL.Image import new as new_image
import os
import sys
from random import randint

COLORS = {"orange": (255, 0, 0), "williams yellow": (255, 190, 10)}
SMALL_NUMBER = 0.000001

class Pixel:
    def __init__(self, red, green, blue, alpha):
        self.red = red
        self.green = green
        self.blue = blue
        self.alpha = alpha
        self.brightness = 0.299*self.red + 0.587*self.green + 0.114*self.blue # standard formula for computing "brightness"
    
    def update_to_fall_colors(self):
        pass


def average_rgb_of_red_pixels(img_2d_list):

    return (0, 0, 0)

def create_blank_canvas(rows, cols, color):

    img_2d_list = []

    return img_2d_list


def transform_img_to_fall_colors(img_2d_list, reference_img):

    pass

def extract_pumpkin_head(pumpkin_heads_img, pumpkin_num):
    
    img = []

    return img

def place_pumpkin_head(character_images, pumpkin_heads_img):
    
    # first eraser head
    
    # then pumpkin(g) king
    return character_images



def read_image_to_list(path):
    img = open_image(path)
    img = img.convert("RGBA")
    rows = img.size[1]
    cols = img.size[0]
    img_1d_list = list(img.getdata())
    img_2d_list = []
    for i in range(rows):
        row = []
        for j in range(cols):
            pixel = img_1d_list[i*cols + j]
            row += [Pixel(pixel[0], pixel[1], pixel[2], pixel[3])]
        img_2d_list += [row]
    return img_2d_list

def write_list_to_image(img_2d_list, path):
    rows = len(img_2d_list)
    cols = len(img_2d_list[0])
    img_1d_list = []
    for i in range(rows):
        for j in range(cols):
            pixel = img_2d_list[i][j]
            img_1d_list += [(pixel.red, pixel.green, pixel.blue, pixel.alpha)]

    img = new_image("RGBA", (cols, rows))
    img.putdata(img_1d_list)
    if path is None:
        img.show()
    else:
        img.save(path)
    

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "canvas":
        red_image = create_blank_canvas(400, 400, COLORS["williams yellow"])
        write_list_to_image(red_image, None)

    elif len(sys.argv) > 1 and sys.argv[1] == "fall":
        cleaf_path = os.path.join("..", "graphics", "nomekop", "Cleaf.png")
        cleaf_img = read_image_to_list(cleaf_path)
        write_list_to_image(cleaf_img, None)
        fall_leaf_path = os.path.join("..", "graphics", "backgrounds", "leaf.jpg")
        fall_leaf_img = read_image_to_list(fall_leaf_path)
        transform_img_to_fall_colors(cleaf_img, fall_leaf_img)
        write_list_to_image(cleaf_img, None)

    elif len(sys.argv) > 1 and sys.argv[1] == "pumpkin":
        pumpkin_path = os.path.join("..", "graphics", "characters", "pumpkin_heads.png")
        pumpkin_heads = read_image_to_list(pumpkin_path)
        write_list_to_image(pumpkin_heads, None)
        pumpkin = extract_pumpkin_head(pumpkin_heads, 1)
        write_list_to_image(pumpkin, None)

    elif len(sys.argv) > 1 and sys.argv[1] == "heads":
        pumpkin_path = os.path.join("..", "graphics", "characters", "pumpkin_heads.png")
        pumpkin_heads = read_image_to_list(pumpkin_path)
        character_path = os.path.join("..", "graphics", "characters", "c5.png")
        character = read_image_to_list(character_path)
        write_list_to_image(character, None)
        place_pumpkin_head(character, pumpkin_heads)
        write_list_to_image(character, None)

    elif len(sys.argv) > 1 and sys.argv[1] == "pixel":
        print("test for average red color")
        ref_img = [[Pixel(120, 1, 100, 0), Pixel(240, 100, 100, 255)], [Pixel(120, 120, 1, 120), Pixel(181, 120, 120, 255)]]
        print(average_rgb_of_red_pixels(ref_img))

        print()
        print("test for single pixel color transformation")
        p1 = Pixel(0, 120, 0, 255)
        print("Pixel 1 start r, g, b = ", p1.red, p1.green, p1.blue)
        p1.update_to_fall_colors()
        print("Pixel 1 after update r, g, b = ", p1.red, p1.green, p1.blue)
        # add another two tests

        
        
