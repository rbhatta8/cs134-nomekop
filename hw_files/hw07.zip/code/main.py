from settings import *
import pygame as pg
from pytmx.util_pygame import load_pygame
from support import load_all_images, player_is_blocked_by_object, load_frames
import sys
import os
from halloween import write_list_to_image, read_image_to_list, place_pumpkin_head, transform_img_to_fall_colors

class Sproot:
    def __init__(self, name, x, y, width, height, images, direction="left"):
        self.name = name
        # attributes defining the rectangle
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        # attributes controlling how the sproot gets drawn on screen
        self.all_images = images # list of all images for this sprite
        self.direction = direction
        direction_index_map = {"left": 0, "right": 4, "down": 8, "up": 12}
        self.current_image = self.all_images[direction_index_map[self.direction]] # set current image

def load_terrain(map):
    
    # get terrain tiles
    terrain = map.get_layer_by_name("Terrain")
    terrain_sproots = []
    for x, y, surface in terrain.tiles():
        s = Sproot("terrain", x * TILE_SIZE,  y * TILE_SIZE, TILE_SIZE, TILE_SIZE, images=[surface])
        terrain_sproots += [s]

    return terrain_sproots

def load_objects(map):
    
    # get terrain tiles
    objects = map.get_layer_by_name("Objects")
    object_sproots = []
    for object in objects:
        s = Sproot("obj", object.x, object.y, object.width, object.height, [object.image])
        object_sproots += [s]
    return object_sproots

def return_y(sproot):
    return sproot.y

def move_player(player_sproot, object_sproots, key_pressed_map, time, walking_speed):
    # code to move player
    add_x = 0
    add_y = 0
    if key_pressed_map[pg.K_LEFT]:
        add_x -= 1
        player_sproot.direction = "left"
    elif key_pressed_map[pg.K_RIGHT]:
        add_x += 1
        player_sproot.direction = "right"
    elif key_pressed_map[pg.K_DOWN]:
        add_y += 1
        player_sproot.direction = "down"
    elif key_pressed_map[pg.K_UP]:
        add_y -= 1
        player_sproot.direction = "up"

    if not player_is_blocked_by_object(player_sproot, object_sproots):
        player_sproot.x += add_x * time * walking_speed
        player_sproot.y += add_y * time * walking_speed
    return player_sproot

def update_sproot_image(sproot, frame):
    # code to update image of a sproot based on the given frame and direction the sproot is facing
    direction_index_map = {"left": 0, "right": 4, "down": 8, "up": 12}
    index = direction_index_map[sproot.direction] + int(frame%4)
    sproot.current_image = sproot.all_images[index]
    return sproot

def draw(image, screen, pos_x, pos_y):
    screen.blit(image, (pos_x, pos_y))


def run_game():

    # initial setup code
    pg.init()
    screen = pg.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
    pg.display.set_caption("Nomékop")
    clock = pg.time.Clock()
    world_map = load_pygame(os.path.join("..", "data", "maps", "icey_prison.tmx"))

    # loading player and friolera images
    player_image_path = os.path.join("..", "graphics", "characters", PLAYER_FILE[0:-4] + "_pumpkin.png")
    prof_image_path = os.path.join("..", "graphics", "characters", PROFESSOR_FILE)
    player_images = load_all_images(player_image_path, 4, 4)
    prof_images = load_all_images(prof_image_path, 4, 4)
    player_sproot = Sproot("Player", 700, 272, 100, 128, player_images, direction="down")
    prof_sproot = Sproot("Prof", 700, 572, 100, 128, prof_images, direction="right")

    terrain_sproots = load_terrain(world_map)
    object_sproots = load_objects(world_map)
    grass_nomekop = ["Cleaf", "Plumette", "Pluma", "Larvea"]
    x = 900
    y = 300
    nomekop_sproots = []
    for nomekop in grass_nomekop:
        images = load_frames(nomekop, flip=True, fall=False)
        object_sproots += [Sproot(nomekop, x, y, 150, 150, images)]
        nomekop_sproots += [object_sproots[-1]]
        fall_images = load_frames(nomekop, flip=False, fall=True)
        object_sproots += [Sproot(nomekop, x+250, y, 150, 150, fall_images)]
        nomekop_sproots += [object_sproots[-1]]
        y+= 200
    
    object_sproots += [player_sproot]
    object_sproots += [prof_sproot]

    frame = 0
    audio_path = os.path.join("..", "data", "audio", "dancing_skeletons.mp3")
    music = pg.mixer.Sound(audio_path)
    music.play()
    print("Prof: Spooooky! Psst.. hey here's some Nomekop storage balls... maybe take Cleaf and Plumette with you to try and bust yourself out of this icy prison...")

    while True:
        
        time = clock.tick() / 1000
        # event loop
        for event in pg.event.get():
            if event.type == pg.QUIT:
                 pg.quit()
                 sys.exit()

        # update the frame based on time and animation speed
        frame += time * ANIMATION_SPEED

        # player movement logic and animation logic
        key_pressed_map = pg.key.get_pressed()
        player_sproot = move_player(player_sproot, object_sproots, key_pressed_map, time, WALKING_SPEED)
        if key_pressed_map[pg.K_LEFT] or key_pressed_map[pg.K_RIGHT] or key_pressed_map[pg.K_DOWN] or key_pressed_map[pg.K_UP]:
            player_sproot = update_sproot_image(player_sproot, frame)
        for s in nomekop_sproots:
            s = update_sproot_image(s, frame)

        # drawing logic
        x_offset = -(player_sproot.x + player_sproot.width/2 - WINDOW_WIDTH/2)
        y_offset = -(player_sproot.y + player_sproot.height/2 - WINDOW_HEIGHT/2)  

        # always reset the screen with a blank slate first
        screen.fill("black")
        
        for s in terrain_sproots:
            draw(s.current_image, screen, s.x + x_offset, s.y + y_offset)
    
        object_sproots = sorted(object_sproots, key=return_y)

        for s in object_sproots:
            draw(s.current_image, screen, s.x + x_offset, s.y + y_offset)

        pg.display.update()


if __name__ == "__main__":
    pumpkin_path = os.path.join("..", "graphics", "characters", "pumpkin_heads.png")
    pumpkin_heads = read_image_to_list(pumpkin_path)
    character_path = os.path.join("..", "graphics", "characters", PLAYER_FILE)
    write_path = os.path.join("..", "graphics", "characters", PLAYER_FILE[0:-4] + "_pumpkin.png")
    character = read_image_to_list(character_path)
    place_pumpkin_head(character, pumpkin_heads)
    write_list_to_image(character, write_path)

    fall_leaf_path = os.path.join("..", "graphics", "backgrounds", "leaf.jpg")
    fall_leaf_img = read_image_to_list(fall_leaf_path)

    grass_nomekop = ["Cleaf", "Pluma", "Plumette", "Larvea"]
    for nomekop in grass_nomekop:
        path = os.path.join("..", "graphics", "nomekop", nomekop + ".png")
        write_path = os.path.join("..", "graphics", "nomekop", nomekop + "_fall.png")
        img = read_image_to_list(path)    
        transform_img_to_fall_colors(img, fall_leaf_img)
        write_list_to_image(img, write_path)

    run_game()